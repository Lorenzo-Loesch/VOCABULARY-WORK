var mudarTexto = document.getElementById("texto");

function selecionarUnidade4() {
  document.getElementById("unit4").disabled = true;
  document.getElementById("unit5").disabled = false;
  document.getElementById("unit6").disabled = false;
  document.getElementById("unit7").disabled = false;
  mudarTexto.innerHTML =
    "<img src='https://images-na.ssl-images-amazon.com/images/I/81Dl5GdAVkL.png' class='imagem'/> <p class='textos'>This is a red apple</p> <img src='https://images-eu.ssl-images-amazon.com/images/I/414iTK-C1CL._SY300_SX300_QL70_FMwebp_.jpg' class='imagem'/> <p class='textos'>I like carrots because they are good for health. </p> <img src='https://c.pxhere.com/images/ab/f4/d4db1d58b4b752162b431dd500e8-1456355.jpg!d' class='imagem'/> <p class='textos'>Fizzy drinks can have a lot of colours. </p> <img src='https://images.everydayhealth.com/images/diet-nutrition/all-about-rice-722x406.jpg' class='imagem'/> <p class='textos'>Rice is a traditional food from Japan </p> <img src='https://media.istockphoto.com/photos/cheese-on-white-picture-id1127471287?s=612x612' class='imagem'/> <p class='textos'>Some cheese has holes, but it don’t mean it isn’t good! </p> <img src='https://www.collinsdictionary.com/images/thumb/egg_110803370_250.jpg?version=4.0.185' class='imagem'/> <p class='textos'>The colour of an egg it’s the colour of the chicken! </p> <img src='https://images.indianexpress.com/2020/07/fruits_getty759.jpg' class='imagem'/> <p class='textos'>We are lucky to live in Brazil, because here we have a lot of great fruits to make delicious juices!  </p> <img src='https://www.cityofpriorlake.com/home/showpublishedimage/1078/637384528077200000' class='imagem'/> <p class='textos'>You need to drink two liters of water per day.   </p> <img src='https://www.eatthis.com/wp-content/uploads/sites/4/2020/03/variety-of-beans.jpg?quality=82&strip=1&resize=640%2C360' class='imagem'/> <p class='textos'>We have a lot of beans, but, in Brazil, we eat most the brown beans, and, in some places, the black beans.</p> <img src='https://www.maangchi.com/wp-content/uploads/2018/02/roasted-chicken-1.jpg' class='imagem'/> <p class='textos'>Some people prefer chicken than meat. </p> <img src='https://previews.123rf.com/images/larisamystock/larisamystock2002/larisamystock200200119/140712114-rustic-style-fish-food-close-up-herring-fish-on-an-old-blue-wooden-background-copy-space-for-text-or.jpg' class='imagem'/> <p class='textos'>I don’t know why people eat a entire fish, it eyes are really strange to eat! </p> <img src='https://media.gettyimages.com/photos/raw-meat-assortment-beef-chicken-and-pork-chops-shot-from-above-on-picture-id1186333343?s=612x612' class='imagem'/> <p class='textos'>One cow gives for us a lot of types of meat! </p>";
}

function selecionarUnidade5() {
  document.getElementById("unit4").disabled = false;
  document.getElementById("unit5").disabled = true;
  document.getElementById("unit6").disabled = false;
  document.getElementById("unit7").disabled = false;
  mudarTexto.innerHTML =
    "<img src='https://www.montblanc.com/variants/images/34480784411828311/A/w2500.jpg' class='imagem'/> <p class='textos'>Belts are good for hold big trousers</p> <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5y67OYX8gIWxBk02FqiC9hga3Lh2N3lB_-g&usqp=CAU' class='imagem'/> <p class='textos'>Shy people always use hoodies because it don’t show the face.</p> <img src='http://cdn.shopify.com/s/files/1/2197/1801/products/18-GAUGE-FIXED-DIAMOND-BEAD_-EARRING.jpg?v=1605297837' class='imagem'/> <p class='textos'>Often people just use one earring, but some people use a lot of! </p> <img src='https://www.casasbahia-imagens.com.br/Control/ArquivoExibir.aspx?IdArquivo=1320051228' class='imagem'/> <p class='textos'>In Brazil, havainas is a famous type of flip-flops! </p> <img src='https://cdn.awsli.com.br/1000x1000/1057/1057655/produto/47465066/b8167fe509.jpg' class='imagem'/> <p class='textos'>People put in their t-shirts things do they like. </p> <img src='https://rohan.imgix.net/product/05638Q43.jpg?w=2500&auto=format&q=77' class='imagem'/> <p class='textos'>Usually, shirts are good for do bunisses Jobs.</p> <img src='https://cdn.shopify.com/s/files/1/2551/1238/collections/40d24758fb71d48302d6f0cef275aa64.jpg?v=1583680312' class='imagem'/> <p class='textos'>Some people use necklaces with a cross. </p> <img src='https://cdn.shopify.com/s/files/1/0021/0288/6455/products/20210604_F.ENES_SCARFME_LOOKBOOK_0407copy_1024x1024.jpg?v=1623802774' class='imagem'/> <p class='textos'>Scarfs are fashion clothes from Europe. </p> <img src='https://cdn.shopify.com/s/files/1/0769/5589/products/IMG_9225_800x.jpg?v=1487462730' class='imagem'/> <p class='textos'>Some purses are very small, so you just can put coins in it. </p> <img src='https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/best-fashion-trainers-1619694969.png?crop=0.899xw:0.715xh;0.101xw,0.256xh&resize=1200:*' class='imagem'/> <p class='textos'>Trainers are good clothes for do sports. </p> <img src='https://d392p56yqvuqpz.cloudfront.net/catalog/product/cache/3a7d73b273444c45342f4a154051cfe1/y/a/ya2388-1.jpg' class='imagem'/> <p class='textos'>A lot of people think skirts are just short clothes, but some skirts are really long. </p> <img src='https://www.motor-x.com/thumbs/830x730x1x1/images/36/7a9fc14ec9c371a138c44eb7a4a8d709.jpg' class='imagem'/> <p class='textos'>We have a lot of types of gloves, for example, the gloves without the fingers are for ride a bike. </p> <img src='https://previews.123rf.com/images/kae2nata/kae2nata1806/kae2nata180600052/105098245-man-finger-hand-opend-brown-empty-wallet-without-money-on-white-background.jpg' class='imagem'/> <p class='textos'>I don’t have any money in my wallet, and you? </p>";
}

function selecionarUnidade6() {
  document.getElementById("unit4").disabled = false;
  document.getElementById("unit5").disabled = false;
  document.getElementById("unit6").disabled = true;
  document.getElementById("unit7").disabled = false;
  mudarTexto.innerHTML =
    "<img src='https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/molly-huddle-of-united-states-competes-in-the-womens-5000-news-photo-1586466671.jpg?crop=0.694xw:1.00xh;0.155xw,0&resize=640:*' class='imagem'/> <p class='textos'>Athletics is a good sport for the legs</p>";
}

function selecionarUnidade7() {
  document.getElementById("unit4").disabled = false;
  document.getElementById("unit5").disabled = false;
  document.getElementById("unit6").disabled = false;
  document.getElementById("unit7").disabled = true;
  mudarTexto.innerHTML =
    "<img src='https://www.teclasap.com.br/wp-content/uploads/2015/05/bear.jpg' class='imagem'/> <p class='textos'>There are a lot of bears in Canada</p>";
}
